"""Helpers for validation: write a minimal safetensors file without the library."""
import json
import struct

import numpy as np

_CODE = {np.dtype("float32"): "F32", np.dtype("float16"): "F16", np.dtype("int64"): "I64"}


def write_safetensors(path, tensors, header_override=None):
    header, blobs, off = {}, [], 0
    for name, a in tensors.items():
        raw = np.ascontiguousarray(a).tobytes()
        header[name] = {"dtype": _CODE[a.dtype], "shape": list(a.shape), "data_offsets": [off, off + len(raw)]}
        blobs.append(raw)
        off += len(raw)
    if header_override:
        header_override(header)
    h = json.dumps(header).encode()
    h += b" " * ((8 - len(h) % 8) % 8)
    with open(path, "wb") as f:
        f.write(struct.pack("<Q", len(h)) + h + b"".join(blobs))
