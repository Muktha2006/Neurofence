"""Week 2 - neuron heatmap data (layers x neurons) + fast RGB rendering."""
import json

import numpy as np

STOPS = np.array([[0, 0, 4], [60, 15, 110], [180, 55, 90], [250, 140, 20], [252, 255, 164]], float)


def _pool(m, bins, how):
    L, W = m.shape
    if not bins or bins >= W:
        return m
    edges = np.linspace(0, W, bins + 1).astype(int)[:-1]
    sums = np.add.reduceat(m, edges, axis=1)
    cnt = np.diff(np.append(edges, W))
    return sums / cnt if how == "mean" else sums / cnt


def build_matrix(baseline, kind="activity", bins=256):
    """kind='activity': log-scaled mean energy normalised per layer (0..1).
    kind='dormant': fraction of neurons that are dormant (<5% of the layer's mean energy).
    bins=None/0 keeps full neuron resolution."""
    rows = []
    for l in sorted(baseline.stats):
        mu = baseline.mean(l)
        ref = max(float(np.mean(mu)), 1e-12)
        rows.append(np.log1p(mu / ref) if kind == "activity" else (mu < 0.05 * ref).astype(np.float64))
    m = _pool(np.vstack(rows), bins, "mean")
    if kind == "activity":
        m = m / max(np.percentile(m, 99.5), 1e-12)
    return np.clip(m, 0, 1).astype(np.float32)


def to_json(matrix, path, meta=None):
    L, C = matrix.shape
    with open(path, "w") as f:
        json.dump({"format": "neurofence-heatmap-v1", "layers": L, "cols": C,
                   "meta": meta or {}, "data": np.round(matrix, 3).tolist()}, f, separators=(",", ":"))


def from_json(path):
    with open(path) as f:
        d = json.load(f)
    if d.get("format") != "neurofence-heatmap-v1":
        raise ValueError("not a NeuroFence heatmap file")
    m = np.asarray(d["data"], np.float32)
    if m.shape != (d["layers"], d["cols"]):
        raise ValueError("heatmap shape mismatch")
    return m, d.get("meta", {})


_LUT = np.stack([np.interp(np.linspace(0, 1, 256), np.linspace(0, 1, len(STOPS)), STOPS[:, c])
                 for c in range(3)], axis=1).astype(np.uint8)


def render_rgb(matrix):
    """(layers, cols) in 0..1 -> uint8 (layers, cols, 3), contiguous, ready for QImage."""
    idx = np.clip(matrix * 255, 0, 255).astype(np.uint8)
    return np.ascontiguousarray(_LUT[idx])
