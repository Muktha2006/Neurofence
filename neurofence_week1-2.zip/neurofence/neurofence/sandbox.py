"""Week 1 - model sandbox.

Rules: only .safetensors (a pure tensor container - loading it cannot execute
code), never pickle formats (.bin/.pt/.pkl/.ckpt run arbitrary code on load),
never `trust_remote_code`, no network. Metadata is read by parsing the
safetensors header by hand, so inspecting a model needs no ML libraries and
no tensor data is ever loaded.
"""
import hashlib
import json
import os
import re
import struct
from collections import Counter
from dataclasses import dataclass, field

PICKLE_EXT = {".bin", ".pt", ".pth", ".pkl", ".pickle", ".ckpt", ".joblib", ".npy"}
MAX_HEADER = 100 * 1024 * 1024
DTYPE_BYTES = {"F64": 8, "F32": 4, "F16": 2, "BF16": 2, "I64": 8, "I32": 4, "I16": 2,
               "I8": 1, "U8": 1, "BOOL": 1, "F8_E4M3": 1, "F8_E5M2": 1,
               "U16": 2, "U32": 4, "U64": 8}


class UnsafeModelError(Exception):
    pass


@dataclass
class SecurityReport:
    path: str
    ok: bool = True
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    safetensors_files: list = field(default_factory=list)


def read_safetensors_header(path):
    """Parse + validate a safetensors header. Returns (tensors, metadata, data_size)."""
    size = os.path.getsize(path)
    if size < 8:
        raise UnsafeModelError("file too small to be safetensors")
    with open(path, "rb") as f:
        (n,) = struct.unpack("<Q", f.read(8))
        if n > MAX_HEADER or 8 + n > size:
            raise UnsafeModelError(f"implausible header length {n}")
        raw = f.read(n)
    try:
        header = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise UnsafeModelError(f"header is not valid JSON: {e}")
    if not isinstance(header, dict):
        raise UnsafeModelError("header is not an object")
    meta = header.pop("__metadata__", {}) or {}
    data_size = size - 8 - n
    spans = []
    for name, t in header.items():
        try:
            dt, shape, (a, b) = t["dtype"], t["shape"], t["data_offsets"]
        except Exception:
            raise UnsafeModelError(f"malformed entry for tensor '{name}'")
        if dt not in DTYPE_BYTES:
            raise UnsafeModelError(f"unknown dtype {dt} in '{name}'")
        count = 1
        for d in shape:
            if not isinstance(d, int) or d < 0:
                raise UnsafeModelError(f"bad shape in '{name}'")
            count *= d
        if not (0 <= a <= b <= data_size):
            raise UnsafeModelError(f"tensor '{name}' data offsets outside the file")
        if b - a != count * DTYPE_BYTES[dt]:
            raise UnsafeModelError(f"tensor '{name}' size does not match dtype/shape")
        spans.append((a, b, name))
    spans.sort()
    for (a1, b1, n1), (a2, b2, n2) in zip(spans, spans[1:]):
        if a2 < b1:
            raise UnsafeModelError(f"tensors '{n1}' and '{n2}' overlap")
    return header, meta, data_size


def check_model_path(path):
    rep = SecurityReport(path)
    if not os.path.exists(path):
        rep.ok = False
        rep.errors.append("path does not exist")
        return rep
    if os.path.isfile(path):
        files = [path]
        ext = os.path.splitext(path)[1].lower()
        if ext in PICKLE_EXT:
            rep.errors.append(f"{ext} is a pickle-style format that can execute code on load - refused")
        elif ext != ".safetensors":
            rep.errors.append(f"unsupported file type '{ext}' (only .safetensors)")
    else:
        files = [os.path.join(path, f) for f in sorted(os.listdir(path))]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            base = os.path.basename(f)
            if ext in PICKLE_EXT:
                rep.warnings.append(f"{base}: pickle-style file present - will NOT be loaded")
            if ext == ".py":
                rep.warnings.append(f"{base}: python code shipped with the model - never executed")
        cfg = os.path.join(path, "config.json")
        if os.path.exists(cfg):
            try:
                if "auto_map" in json.load(open(cfg)):
                    rep.warnings.append("config.json requests custom code (auto_map) - ignored")
            except Exception:
                rep.warnings.append("config.json is not valid JSON")
        files = [f for f in files if f.lower().endswith(".safetensors")]
        if not files:
            rep.errors.append("no .safetensors weights found")
    for f in files:
        if f.lower().endswith(".safetensors") and not rep.errors:
            try:
                read_safetensors_header(f)
                rep.safetensors_files.append(f)
            except UnsafeModelError as e:
                rep.errors.append(f"{os.path.basename(f)}: {e}")
    rep.ok = not rep.errors
    return rep


def summarize_model(report):
    """Basic metadata for the UI (header only; no tensor data is read)."""
    dtypes, layers, params, total, tensors = Counter(), set(), 0, 0, []
    fmt = {}
    for f in report.safetensors_files:
        header, meta, _ = read_safetensors_header(f)
        fmt.update(meta)
        total += os.path.getsize(f)
        for name, t in header.items():
            n = 1
            for d in t["shape"]:
                n *= d
            params += n
            dtypes[t["dtype"]] += n
            tensors.append((name, t["dtype"], tuple(t["shape"]), n))
            m = re.search(r"\.(?:layers|h|blocks)\.(\d+)\.", name)
            if m:
                layers.add(int(m.group(1)))
    tensors.sort(key=lambda x: -x[3])
    return {"files": [os.path.basename(f) for f in report.safetensors_files],
            "bytes": total, "tensors": len(tensors), "params": params,
            "dtypes": dict(dtypes), "layers": (max(layers) + 1) if layers else None,
            "format_metadata": fmt, "largest": tensors[:50]}


def sha256_file(path, progress=None, chunk=8 << 20):
    h, size, done = hashlib.sha256(), os.path.getsize(path), 0
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
            done += len(b)
            if progress:
                progress(done, size)
    return h.hexdigest()


def harden_process(mem_limit_gb=None):
    """Offline lock-down for the current process: no network, optional RAM cap."""
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      HF_DATASETS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1")
    import socket

    def blocked(*a, **k):
        raise PermissionError("network access disabled by NeuroFence sandbox")
    socket.socket.connect = blocked
    socket.socket.connect_ex = blocked
    socket.getaddrinfo = blocked
    if mem_limit_gb:
        try:
            import resource
            lim = int(mem_limit_gb * (1 << 30))
            resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
        except (ImportError, ValueError, OSError):
            pass
