"""NeuroFence - offline LLM weight-poisoning & backdoor scanner."""
__version__ = "0.2.0"  # weeks 1-2
