"""Week 2 - fuzz the model and record the baseline activation distribution."""
import argparse
import json

import numpy as np

from .fuzzer import generate, summary
from .stats import ActivationTracker, RunningStats


class Baseline:
    def __init__(self, stats, meta=None):
        self.stats = stats                  # {layer: RunningStats}
        self.meta = meta or {}

    @property
    def n_layers(self):
        return len(self.stats)

    def mean(self, l): return self.stats[l].mean
    def std(self, l): return self.stats[l].std
    def peak(self, l): return self.stats[l].max

    def save(self, path):
        arr = {"meta": np.array(json.dumps(self.meta))}
        for l, s in self.stats.items():
            arr[f"n_{l}"], arr[f"mean_{l}"] = np.array(s.n), s.mean
            arr[f"m2_{l}"], arr[f"max_{l}"] = s.m2, s.max
        np.savez_compressed(path, **arr)

    @classmethod
    def load(cls, path):
        z = np.load(path, allow_pickle=False)
        stats = {}
        for k in z.files:
            if k.startswith("mean_"):
                l = int(k[5:])
                s = RunningStats(len(z[k]))
                s.n, s.mean, s.m2, s.max = int(z[f"n_{l}"]), z[k], z[f"m2_{l}"], z[f"max_{l}"]
                stats[l] = s
        return cls(dict(sorted(stats.items())), json.loads(str(z["meta"])))


def run_baseline(runner, prompts, batch_size=8, progress=None, cancelled=None):
    tracker = ActivationTracker()
    texts = [p.text for p in prompts]
    for i in range(0, len(texts), batch_size):
        if cancelled and cancelled():
            break
        runner.run(texts[i:i + batch_size], tracker)
        if progress:
            progress(min(i + batch_size, len(texts)), len(texts))
    meta = {"prompts": tracker.stats[0].n if tracker.stats else 0,
            "categories": summary(prompts), "model": getattr(runner, "name", "?")}
    return Baseline(tracker.stats, meta)


def main():
    from .heatmap import build_matrix, to_json
    from .runners import ToyRunner, TorchRunner
    ap = argparse.ArgumentParser(description="Fuzz a local model and record its baseline activations.")
    ap.add_argument("--model", help="folder with config.json, tokenizer and .safetensors")
    ap.add_argument("--demo", action="store_true", help="use the built-in toy model")
    ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--out", default="baseline.npz")
    ap.add_argument("--heatmap-json")
    a = ap.parse_args()
    if a.demo:
        runner = ToyRunner()
    elif a.model:
        from .sandbox import harden_process
        harden_process()
        runner = TorchRunner(a.model, a.device)
    else:
        ap.error("give --model DIR or --demo")
    bl = run_baseline(runner, generate(a.n, a.seed), a.batch,
                      progress=lambda i, n: print(f"\r{i}/{n}", end="", flush=True))
    print()
    bl.save(a.out)
    print("saved", a.out, bl.meta)
    if a.heatmap_json:
        to_json(build_matrix(bl, "activity", 256), a.heatmap_json, {"kind": "activity"})


if __name__ == "__main__":
    main()
