"""Mid-project review: hooking audit, sandbox safety, fuzzer, and heavy-payload data load.

    python -m neurofence.validate [--preview heatmap.png]
"""
import argparse
import os
import subprocess
import sys
import tempfile
import time
import tracemalloc

import numpy as np

from ._testing import write_safetensors
from .baseline import Baseline, run_baseline
from .fuzzer import generate, summary
from .heatmap import build_matrix, from_json, render_rgb, to_json
from .runners import ToyRunner
from .sandbox import check_model_path, sha256_file, summarize_model
from .stats import ActivationTracker


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name} {detail}")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preview")
    a = ap.parse_args()
    res = []
    tmp = tempfile.mkdtemp()

    print("1. Hooking audit: tracker vs ground truth on the toy model")
    toy = ToyRunner()
    prompts = [p.text for p in generate(64, 3)]
    tr = ActivationTracker(keep_last=True)
    toy.run(prompts, tr)
    ids, mask = toy.encode(prompts)
    h = toy.emb[ids]
    worst = 0.0
    for l in range(toy.n_layers):
        acts = np.maximum(h @ toy.w1[l] - toy.b[l], 0)
        truth = (np.abs(acts) * mask[..., None]).sum(1) / mask.sum(1, keepdims=True)
        worst = max(worst, float(np.abs(truth - tr.last[l]).max()))
        h = h + 0.5 * (acts @ toy.w2[l])
        h = h / np.sqrt((h ** 2).mean(-1, keepdims=True) + 1e-6)
    res.append(check("per-neuron energies exact", worst < 1e-4, f"(max error {worst:.2e}, {toy.n_layers} layers x 256 neurons)"))
    bl_full = run_baseline(ToyRunner(), generate(200, 1), 8)
    s = bl_full.stats[0]
    res.append(check("running stats = batch stats", s.n == 200 and np.all(s.std >= 0)))

    print("2. Hooking audit: no memory leak over 300 batches")
    t2, bt = ToyRunner(), ActivationTracker()
    texts = [p.text for p in generate(8, 5)]
    for _ in range(30):
        t2.run(texts, bt)
    tracemalloc.start()
    base = tracemalloc.take_snapshot()
    for _ in range(300):
        t2.run(texts, bt)
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    res.append(check("memory stays flat", cur < 512 * 1024, f"(residual {cur/1024:.0f} KiB after 300 batches)"))

    print("3. Sandbox safety")
    good = os.path.join(tmp, "m.safetensors")
    write_safetensors(good, {"model.layers.0.mlp.down_proj.weight": np.zeros((4, 8), np.float32),
                             "model.layers.1.mlp.down_proj.weight": np.zeros((4, 8), np.float32)})
    rep = check_model_path(good)
    info = summarize_model(rep) if rep.ok else {}
    res.append(check("valid safetensors accepted + metadata", rep.ok and info.get("params") == 64 and info.get("layers") == 2,
                     f"({info.get('params')} params, {info.get('layers')} layers)"))
    pk = os.path.join(tmp, "evil.pt")
    open(pk, "wb").write(b"\x80\x04cos\nsystem\n")
    res.append(check("pickle file refused", not check_model_path(pk).ok))
    bad = os.path.join(tmp, "bad.safetensors")
    write_safetensors(bad, {"w": np.zeros(4, np.float32)}, lambda h: h["w"].update(data_offsets=[0, 9999]))
    res.append(check("out-of-bounds offsets refused", not check_model_path(bad).ok))
    ov = os.path.join(tmp, "ov.safetensors")
    write_safetensors(ov, {"a": np.zeros(4, np.float32), "b": np.zeros(4, np.float32)},
                      lambda h: h["b"].update(data_offsets=[8, 24]))
    res.append(check("overlapping tensors refused", not check_model_path(ov).ok))
    res.append(check("sha256 matches", len(sha256_file(good)) == 64))
    code = ("from neurofence.sandbox import harden_process;harden_process();import socket,sys\n"
            "try:\n socket.create_connection(('127.0.0.1',9),timeout=1);sys.exit(1)\n"
            "except PermissionError:\n sys.exit(0)\nexcept Exception:\n sys.exit(2)")
    rc = subprocess.run([sys.executable, "-c", code], cwd=os.path.dirname(os.path.dirname(__file__))).returncode
    res.append(check("network blocked after harden_process()", rc == 0))

    print("4. Fuzzer")
    p1, p2 = generate(5000, 11), generate(5000, 11)
    res.append(check("5000 unique prompts, deterministic", len({x.text for x in p1}) == 5000 and p1 == p2, str(summary(p1))))

    print("5. Data load: full-resolution 32 x 11008 heatmap (~350k neurons) through JSON")
    rng = np.random.default_rng(0)
    big = rng.random((32, 11008), dtype=np.float32) ** 3
    jp = os.path.join(tmp, "big.json")
    to_json(big, jp, {"synthetic": True})
    t0 = time.perf_counter()
    m, _ = from_json(jp)
    t_load = time.perf_counter() - t0
    t0 = time.perf_counter()
    rgb = render_rgb(m)
    t_rend = time.perf_counter() - t0
    res.append(check("JSON load + render", t_load < 3 and t_rend < 0.5 and rgb.shape == (32, 11008, 3),
                     f"({os.path.getsize(jp)/1e6:.1f} MB, load {t_load:.2f}s, render {t_rend*1000:.0f} ms)"))

    if a.preview:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(9, 5))
        for axi, kind in zip(ax, ("activity", "dormant")):
            axi.imshow(render_rgb(build_matrix(bl_full, kind, None)), aspect="auto", interpolation="nearest")
            axi.set_title(f"toy model - {kind} (rows = layers, cols = neurons)", fontsize=9)
        fig.tight_layout()
        fig.savefig(a.preview, dpi=110)
        print("preview written to", a.preview)

    ok = all(res)
    print("\nRESULT:", "all checks passed" if ok else "FAILURES")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
