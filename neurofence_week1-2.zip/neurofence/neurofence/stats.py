"""Activation statistics: framework-independent core of the hooking backend."""
import numpy as np


class RunningStats:
    """Per-neuron running mean / variance / max over prompts (Chan's merge, O(width) memory)."""

    def __init__(self, width):
        self.n = 0
        self.mean = np.zeros(width, np.float64)
        self.m2 = np.zeros(width, np.float64)
        self.max = np.full(width, -np.inf)

    def update(self, x):
        x = np.asarray(x, np.float64)
        nb = x.shape[0]
        if nb == 0:
            return
        mb = x.mean(0)
        m2b = ((x - mb) ** 2).sum(0)
        d, tot = mb - self.mean, self.n + nb
        self.mean += d * nb / tot
        self.m2 += m2b + d * d * self.n * nb / tot
        self.n = tot
        np.maximum(self.max, x.max(0), out=self.max)

    @property
    def std(self):
        return np.sqrt(self.m2 / (self.n - 1)) if self.n > 1 else np.zeros_like(self.mean)


class ActivationTracker:
    """Receives MLP neuron activations [batch, tokens, neurons] for each layer and
    reduces them to one 'activation energy' per prompt and neuron: the mean
    absolute activation over the real (non-padding) tokens. Only running
    statistics are kept, so memory stays constant however many prompts are fed.
    """

    def __init__(self, keep_last=False):
        self.stats = {}
        self.keep_last = keep_last
        self.last = {}

    def record(self, layer, acts, mask):
        acts = np.asarray(acts, np.float32)
        mask = np.asarray(mask, bool)
        denom = np.maximum(mask.sum(1), 1)[:, None]
        e = np.einsum("bti,bt->bi", np.abs(acts), mask.astype(np.float32)) / denom
        st = self.stats.get(layer)
        if st is None:
            st = self.stats[layer] = RunningStats(e.shape[1])
        st.update(e)
        if self.keep_last:
            self.last[layer] = e
        return e
