"""Model runners: the thing that pushes prompts through a model and feeds the tracker.

TorchRunner - real HuggingFace model (forward hooks on every MLP output projection).
ToyRunner   - tiny NumPy transformer-ish model so everything can run/test with no download.
"""
import re
import zlib

import numpy as np

# input of these projections = the MLP's neuron activations (after the nonlinearity)
_MLP_OUT = re.compile(r"\.(\d+)\.(?:mlp\.|feed_forward\.)?(down_proj|c_proj|fc2|dense_4h_to_h|fc_out|w2)$")


class TorchRunner:
    def __init__(self, model_dir, device="cpu", max_len=64):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch, self.device, self.max_len = torch, device, max_len
        self.name = str(model_dir)
        kw = dict(local_files_only=True, trust_remote_code=False)   # sandbox rules
        self.tok = AutoTokenizer.from_pretrained(model_dir, **kw)
        if self.tok.pad_token is None:
            self.tok.pad_token = self.tok.eos_token
        self.tok.padding_side = "right"
        self.model = AutoModelForCausalLM.from_pretrained(
            model_dir, use_safetensors=True, torch_dtype=torch.float32, **kw).to(device).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.tracker, self._mask, self.handles = None, None, []
        for name, mod in self.model.named_modules():
            m = _MLP_OUT.search("." + name)
            if m:
                self.handles.append(mod.register_forward_pre_hook(self._make_hook(int(m.group(1)))))
        if not self.handles:
            raise RuntimeError("no MLP layers found to hook for this architecture")
        self.n_layers = len(self.handles)

    def _make_hook(self, layer):
        def hook(module, args):
            if self.tracker is not None:
                self.tracker.record(layer, args[0].detach().float().cpu().numpy(), self._mask)
        return hook

    def run(self, prompts, tracker):
        t = self.torch
        enc = self.tok(prompts, return_tensors="pt", padding=True, truncation=True,
                       max_length=self.max_len)
        self._mask = enc["attention_mask"].bool().numpy()
        self.tracker = tracker
        try:
            with t.inference_mode():
                self.model(**{k: v.to(self.device) for k, v in enc.items()})
        finally:
            self.tracker = None

    def close(self):
        for h in self.handles:
            h.remove()
        self.handles = []


class ToyRunner:
    """4-layer toy network with hash tokenizer; 30%-ish of neurons are naturally near-dormant."""
    name = "toy-model"

    def __init__(self, layers=4, dim=48, width=256, vocab=1024, max_len=48, seed=0):
        r = np.random.default_rng(seed)
        self.vocab, self.max_len, self.n_layers = vocab, max_len, layers
        self.emb = r.normal(0, 1, (vocab, dim)).astype(np.float32)
        self.w1 = [(r.normal(0, 1, (dim, width)) / np.sqrt(dim)).astype(np.float32) for _ in range(layers)]
        self.b = [r.normal(0.8, 0.9, width).astype(np.float32) for _ in range(layers)]
        self.w2 = [(r.normal(0, 1, (width, dim)) / np.sqrt(width)).astype(np.float32) for _ in range(layers)]

    def encode(self, texts):
        ids = np.zeros((len(texts), self.max_len), np.int64)
        mask = np.zeros((len(texts), self.max_len), bool)
        for i, t in enumerate(texts):
            toks = re.findall(r"\w+|[^\w\s]", t.lower())[:self.max_len] or ["<empty>"]
            ids[i, :len(toks)] = [zlib.crc32(x.encode()) % self.vocab for x in toks]
            mask[i, :len(toks)] = True
        return ids, mask

    def run(self, texts, tracker):
        ids, mask = self.encode(texts)
        h = self.emb[ids]
        for l in range(self.n_layers):
            acts = np.maximum(h @ self.w1[l] - self.b[l], 0)       # the "neurons"
            tracker.record(l, acts, mask)
            h = h + 0.5 * (acts @ self.w2[l])
            h = h / np.sqrt((h ** 2).mean(-1, keepdims=True) + 1e-6)
