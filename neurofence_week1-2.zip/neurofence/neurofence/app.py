"""Week 1-2 desktop app (PyQt6): model loader + metadata, fuzz & baseline, neuron heatmap.

    python -m neurofence.app [--allow-network]
"""
import os
import sys

import numpy as np
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QImage, QPainter
from PyQt6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QLabel,
                             QMainWindow, QPlainTextEdit, QProgressBar, QPushButton, QSpinBox,
                             QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
                             QHeaderView)

from . import heatmap
from .baseline import Baseline, run_baseline
from .fuzzer import generate, summary
from .sandbox import check_model_path, harden_process, sha256_file, summarize_model


class Worker(QThread):
    """Runs fn(progress, cancelled) off the UI thread."""
    progress = pyqtSignal(int, int)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn, self._cancel = fn, False

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            self.done.emit(self.fn(lambda i, n: self.progress.emit(i, n), lambda: self._cancel))
        except Exception as e:
            self.failed.emit(f"{type(e).__name__}: {e}")


def human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} PB"


class ModelTab(QWidget):
    model_selected = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.worker = None
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        b1, b2 = QPushButton("Open .safetensors file…"), QPushButton("Open model folder…")
        b1.clicked.connect(self.pick_file)
        b2.clicked.connect(self.pick_dir)
        row.addWidget(b1)
        row.addWidget(b2)
        row.addStretch()
        lay.addLayout(row)
        self.verdict = QLabel("No model loaded. Only .safetensors is accepted; pickle files are refused.")
        self.verdict.setWordWrap(True)
        lay.addWidget(self.verdict)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Property", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        lay.addWidget(self.table, 1)
        self.tensors = QTableWidget(0, 4)
        self.tensors.setHorizontalHeaderLabels(["Largest tensors", "dtype", "shape", "params"])
        self.tensors.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        lay.addWidget(self.tensors, 2)
        self.bar = QProgressBar()
        self.bar.setVisible(False)
        lay.addWidget(self.bar)

    def pick_file(self):
        p, _ = QFileDialog.getOpenFileName(self, "Model weights", "", "All files (*)")
        if p:
            self.load(p)

    def pick_dir(self):
        p = QFileDialog.getExistingDirectory(self, "Model folder")
        if p:
            self.load(p)

    def set_rows(self, rows):
        self.table.setRowCount(len(rows))
        for i, (k, v) in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(k))
            self.table.setItem(i, 1, QTableWidgetItem(str(v)))

    def load(self, path):
        rep = check_model_path(path)
        self.table.setRowCount(0)
        self.tensors.setRowCount(0)
        if not rep.ok:
            self.verdict.setText("REFUSED: " + "; ".join(rep.errors))
            self.verdict.setStyleSheet("color:#c0392b;font-weight:bold")
            return
        txt = "Safe to inspect (header validated, nothing executed)."
        if rep.warnings:
            txt += "  Notes: " + "; ".join(rep.warnings)
        self.verdict.setText(txt)
        self.verdict.setStyleSheet("color:#1e8449")
        info = summarize_model(rep)
        self.rows = [("Path", path), ("Files", ", ".join(info["files"])), ("Total size", human(info["bytes"])),
                     ("Tensors", f"{info['tensors']:,}"), ("Parameters", f"{info['params']:,}"),
                     ("Transformer layers (from names)", info["layers"] or "unknown"),
                     ("Parameters by dtype", ", ".join(f"{k}: {v:,}" for k, v in info["dtypes"].items())),
                     ("Embedded metadata", info["format_metadata"] or "none"), ("SHA-256", "computing…")]
        self.set_rows(self.rows)
        self.tensors.setRowCount(len(info["largest"]))
        for i, (n, dt, sh, p) in enumerate(info["largest"]):
            for j, v in enumerate((n, dt, "×".join(map(str, sh)), f"{p:,}")):
                self.tensors.setItem(i, j, QTableWidgetItem(v))
        self.model_selected.emit(path if os.path.isdir(path) else os.path.dirname(path))
        files = rep.safetensors_files

        def job(progress, cancelled):
            return [(os.path.basename(f), sha256_file(f, progress)) for f in files]
        self.bar.setVisible(True)
        self.worker = Worker(job)
        self.worker.progress.connect(lambda i, n: (self.bar.setMaximum(max(n, 1)), self.bar.setValue(i)))
        self.worker.done.connect(self._hashed)
        self.worker.failed.connect(lambda m: self.verdict.setText(m))
        self.worker.start()

    def _hashed(self, hashes):
        self.bar.setVisible(False)
        self.rows[-1] = ("SHA-256", "\n".join(f"{n}: {h}" for n, h in hashes))
        self.set_rows(self.rows)
        self.table.resizeRowsToContents()


class FuzzTab(QWidget):
    baseline_ready = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.model_dir, self.worker, self.baseline = None, None, None
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        self.n = QSpinBox(); self.n.setRange(100, 200000); self.n.setValue(2000); self.n.setSingleStep(500)
        self.batch = QSpinBox(); self.batch.setRange(1, 128); self.batch.setValue(8)
        self.seed = QSpinBox(); self.seed.setRange(0, 10 ** 6)
        self.device = QComboBox(); self.device.addItems(["cpu", "cuda"])
        self.demo = QCheckBox("Demo model (built-in toy, no download)")
        for lab, w in (("Prompts", self.n), ("Batch", self.batch), ("Seed", self.seed), ("Device", self.device)):
            row.addWidget(QLabel(lab)); row.addWidget(w)
        row.addWidget(self.demo); row.addStretch()
        lay.addLayout(row)
        row2 = QHBoxLayout()
        self.run_b, self.stop_b = QPushButton("Run fuzzer + record baseline"), QPushButton("Stop")
        self.save_b = QPushButton("Save baseline…")
        self.stop_b.setEnabled(False); self.save_b.setEnabled(False)
        self.run_b.clicked.connect(self.start); self.stop_b.clicked.connect(self.stop)
        self.save_b.clicked.connect(self.save)
        for b in (self.run_b, self.stop_b, self.save_b):
            row2.addWidget(b)
        row2.addStretch()
        lay.addLayout(row2)
        self.bar = QProgressBar(); lay.addWidget(self.bar)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); lay.addWidget(self.log, 1)

    def set_model(self, d):
        self.model_dir = d
        self.log.appendPlainText(f"Model folder: {d}")

    def start(self):
        demo, model_dir = self.demo.isChecked(), self.model_dir
        if not demo and not model_dir:
            self.log.appendPlainText("Load a model on the Model tab first (or tick Demo model).")
            return
        n, batch, seed, dev = self.n.value(), self.batch.value(), self.seed.value(), self.device.currentText()
        prompts = generate(n, seed)
        self.log.appendPlainText(f"Generated {n} prompts: {summary(prompts)}")

        def job(progress, cancelled):
            from .runners import ToyRunner, TorchRunner
            runner = ToyRunner() if demo else TorchRunner(model_dir, dev)
            try:
                return run_baseline(runner, prompts, batch, progress, cancelled)
            finally:
                if hasattr(runner, "close"):
                    runner.close()
        self.worker = Worker(job)
        self.worker.progress.connect(lambda i, t: (self.bar.setMaximum(t), self.bar.setValue(i)))
        self.worker.done.connect(self.finished)
        self.worker.failed.connect(lambda m: (self.log.appendPlainText("ERROR: " + m), self._idle()))
        self.run_b.setEnabled(False); self.stop_b.setEnabled(True)
        self.worker.start()

    def stop(self):
        if self.worker:
            self.worker.cancel()

    def _idle(self):
        self.run_b.setEnabled(True); self.stop_b.setEnabled(False)

    def finished(self, bl):
        self._idle()
        self.baseline = bl
        self.save_b.setEnabled(True)
        self.log.appendPlainText(f"Baseline recorded: {bl.n_layers} layers, {bl.meta.get('prompts')} prompts.")
        self.baseline_ready.emit(bl)

    def save(self):
        p, _ = QFileDialog.getSaveFileName(self, "Save baseline", "baseline.npz", "NumPy (*.npz)")
        if p and self.baseline:
            self.baseline.save(p)


class HeatmapWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.matrix, self.img, self._buf = None, None, None
        self.setMinimumHeight(240)
        self.info = QLabel("")

    def set_matrix(self, m):
        self.matrix = m
        rgb = heatmap.render_rgb(m)
        self._buf = rgb                      # keep alive: QImage does not copy
        L, C = m.shape
        self.img = QImage(rgb.data, C, L, 3 * C, QImage.Format.Format_RGB888)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        if self.img is None:
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No heatmap yet - run the baseline or load a JSON file")
            return
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        p.drawImage(self.rect(), self.img)

    def mouseMoveEvent(self, e):
        if self.matrix is None:
            return
        L, C = self.matrix.shape
        x = min(C - 1, max(0, int(e.position().x() / self.width() * C)))
        y = min(L - 1, max(0, int(e.position().y() / self.height() * L)))
        self.info.setText(f"layer {y}  neuron column {x}  value {self.matrix[y, x]:.3f}")


class HeatTab(QWidget):
    def __init__(self):
        super().__init__()
        self.baseline = None
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        self.kind = QComboBox(); self.kind.addItems(["activity", "dormant"])
        self.bins = QSpinBox(); self.bins.setRange(0, 20000); self.bins.setValue(256)
        self.bins.setSpecialValueText("full resolution")
        load, exp = QPushButton("Load heatmap JSON…"), QPushButton("Export JSON…")
        load.clicked.connect(self.load); exp.clicked.connect(self.export)
        self.kind.currentIndexChanged.connect(self.rebuild); self.bins.editingFinished.connect(self.rebuild)
        for w in (QLabel("View"), self.kind, QLabel("Columns"), self.bins, load, exp):
            row.addWidget(w)
        row.addStretch()
        lay.addLayout(row)
        self.hm = HeatmapWidget()
        lay.addWidget(self.hm, 1)
        lay.addWidget(self.hm.info)
        lay.addWidget(QLabel("Rows = layers, columns = MLP neurons. activity: bright = high mean energy. "
                             "dormant: bright = neuron almost never fires on normal input."))

    def set_baseline(self, bl):
        self.baseline = bl
        self.rebuild()

    def rebuild(self):
        if self.baseline:
            self.hm.set_matrix(heatmap.build_matrix(self.baseline, self.kind.currentText(), self.bins.value() or None))

    def load(self):
        p, _ = QFileDialog.getOpenFileName(self, "Heatmap JSON", "", "JSON (*.json)")
        if p:
            m, _ = heatmap.from_json(p)
            self.hm.set_matrix(m)

    def export(self):
        if self.hm.matrix is None:
            return
        p, _ = QFileDialog.getSaveFileName(self, "Export", "heatmap.json", "JSON (*.json)")
        if p:
            heatmap.to_json(self.hm.matrix, p, {"kind": self.kind.currentText()})


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NeuroFence - LLM backdoor scanner (offline)")
        self.resize(1100, 760)
        tabs = QTabWidget()
        self.model, self.fuzz, self.heat = ModelTab(), FuzzTab(), HeatTab()
        tabs.addTab(self.model, "1  Model")
        tabs.addTab(self.fuzz, "2  Fuzz && Baseline")
        tabs.addTab(self.heat, "3  Neuron heatmap")
        self.model.model_selected.connect(self.fuzz.set_model)
        self.fuzz.baseline_ready.connect(lambda b: (self.heat.set_baseline(b), tabs.setCurrentWidget(self.heat)))
        self.setCentralWidget(tabs)


def main():
    if "--allow-network" not in sys.argv:
        harden_process()
    app = QApplication(sys.argv)
    w = Main()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
