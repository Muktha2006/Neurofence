# NeuroFence (Weeks 1-2)

Offline LLM weight-poisoning & backdoor scanner. Weeks 3 (backdoor injection + detection) and 4 (PDF report + polish) come separately.

## Install / run
    pip install -r requirements.txt
    python -m neurofence.validate --preview heatmap.png       # mid-project review checks (no torch/Qt needed)
    python -m neurofence.app                                  # desktop app (tick "Demo model" to try it with no download)
    python -m neurofence.baseline --demo --n 2000 --heatmap-json hm.json
    python -m neurofence.baseline --model ./TinyLlama-1.1B --n 2000   # real model folder (config + tokenizer + .safetensors)

## Week 1
- `sandbox.py`: only `.safetensors`, pickle formats refused, `trust_remote_code=False`, offline env vars + socket block, header parsed and bounds-checked by hand (no tensor data read to inspect), SHA-256
- `runners.py` `TorchRunner`: loads a local HF model, forward-pre-hooks on every MLP output projection (= the neuron activations); `ToyRunner`: NumPy stand-in for tests/demo
- `app.py`: PyQt6 window with a Model tab (verdict, metadata, largest tensors, hash)

## Week 2
- `fuzzer.py`: deterministic generator (random words, sentences, edge cases, trigger words, adversarial suffixes)
- `baseline.py` + `stats.py`: per-neuron mean/std/max of activation energy across all prompts, constant memory, saved to .npz
- `heatmap.py` + app tab: layers x neurons heatmap (activity / dormant), JSON import/export, tooltip on hover

## Honest limits
- `validate` tests everything that does not need torch, Qt or a downloaded model (stats, fuzzer, sandbox, heatmap/JSON load) against the toy model.
- `TorchRunner` and the PyQt6 UI were written against the documented APIs but not executed in my sandbox (no torch/Qt/network there). Expect to fix small things on first run; hook-layer discovery covers Llama/Mistral/Qwen, GPT-2, OPT, Pythia/NeoX naming.
